# Authors
Jack Normand 
jen88@nau.edu

Henry Fye
shf26@nau.edu
# Usage
Program is a set of tools used for vector math with a test suite included. Simply make and run program to view test completion

To make, type make
To run, type ./v3tester

# Known Issues
None
