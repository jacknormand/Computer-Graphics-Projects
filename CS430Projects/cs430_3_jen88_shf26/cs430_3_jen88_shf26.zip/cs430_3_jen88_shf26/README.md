# Authors
Jack Normand 
jen88@nau.edu

Henry Fye
shf26@nau.edu

# Usage
raycast width height input.csv output.ppm

# Known Issues
None
